package com.chess.elite.data

import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.RoomDatabase
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "games")
data class GameEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val dateMillis: Long = System.currentTimeMillis(),
    val pgnString: String,              // Saved in standard Portable Game Notation
    val whitePlayer: String,
    val blackPlayer: String,
    val result: String,                 // "1-0", "0-1", "1/2-1/2", or "*" indicating ongoing
    val gameMode: String,               // "vs_ai", "pass_and_play", "bluetooth", "puzzles"
    val durationSeconds: Long = 0,
    val openingName: String? = null
)

@Entity(tableName = "player_stats")
data class PlayerStatsEntity(
    @PrimaryKey val id: String = "local_player",
    val rating: Int = 1200,            // Start Glicko/ELO rating
    val puzzlesSolved: Int = 0,
    val puzzlesFailed: Int = 0,
    val winsVsAi: Int = 0,
    val lossesVsAi: Int = 0,
    val drawsVsAi: Int = 0,
    val favoriteOpening: String? = null
)

@Entity(tableName = "saved_puzzles")
data class SavedPuzzleEntity(
    @PrimaryKey val puzzleId: String,
    val rating: Int,
    val themes: String,                 // Comma separated tags (e.g. "mateIn2,fork")
    val fenState: String,
    val solutionMoves: String,          // Comma separated legal moves (e.g. "e2e4,g8f6")
    val solved: Boolean = false,
    val timestamp: Long = System.currentTimeMillis()
)

@Dao
interface ChessDao {
    @Query("SELECT * FROM games ORDER BY dateMillis DESC")
    fun getAllGames(): Flow<List<GameEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertGame(game: GameEntity): Long

    @Query("DELETE FROM games WHERE id = :gameId")
    suspend fun deleteGame(gameId: Long)

    @Query("SELECT * FROM player_stats WHERE id = :playerId")
    suspend fun getPlayerStats(playerId: String = "local_player"): PlayerStatsEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun savePlayerStats(stats: PlayerStatsEntity)

    // Puzzles functions
    @Query("SELECT * FROM saved_puzzles ORDER BY rating ASC")
    fun getAllSavedPuzzles(): Flow<List<SavedPuzzleEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPuzzle(puzzle: SavedPuzzleEntity)

    @Query("UPDATE saved_puzzles SET solved = 1 WHERE puzzleId = :puzzleId")
    suspend fun markPuzzleAsSolved(puzzleId: String)
}

@Database(entities = [GameEntity::class, PlayerStatsEntity::class, SavedPuzzleEntity::class], version = 1, exportSchema = false)
abstract class GameDatabase : RoomDatabase() {
    abstract fun chessDao(): ChessDao
}