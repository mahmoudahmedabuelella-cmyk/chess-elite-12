package com.chess.elite.engine

import android.content.Context
import android.os.Build
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.io.File
import java.io.FileOutputStream
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Handles communication with the Stockfish 18 binary via the Universal Chess Interface (UCI) protocol.
 * Supports ARMv7 and ARMv8 (64-bit) architectures dynamically.
 */
class StockfishEngine(private val context: Context) {

    private var process: Process? = null
    private var reader: BufferedReader? = null
    private var writer: OutputStreamWriter? = null
    private val isRunning = AtomicBoolean(false)
    private val scope = CoroutineScope(Dispatchers.IO + Job())

    // Streams engine analysis outputs (evaluation, best move, lines calculated) to listeners
    private val _engineOutputs = MutableSharedFlow<EngineResponse>(replay = 1)
    val engineOutputs: SharedFlow<EngineResponse> = _engineOutputs

    sealed class EngineResponse {
        data class Ready(val isReady: Boolean) : EngineResponse()
        data class BestMove(val move: String) : EngineResponse()
        data class Info(
            val depth: Int,
            val centipawns: Int?,
            val mateInMoves: Int?,
            val bestLine: List<String>?,
            val raw: String
        ) : EngineResponse()
        data class Error(val message: String) : EngineResponse()
    }

    /**
     * Extracts the appropriate Stockfish binary from 'assets' and ensures executable permissions.
     */
    suspend fun initialize(): Boolean = withContext(Dispatchers.IO) {
        try {
            val abi = Build.SUPPORTED_ABIS.firstOrNull() ?: "armeabi-v7a"
            val assetName = if (abi.contains("arm64-v8a")) {
                "stockfish_18_arm64-v8a"
            } else {
                "stockfish_18_armeabi-v7a"
            }

            val binaryFile = File(context.filesDir, "stockfish")
            
            // Extract the asset if it doesn't exist or is outdated
            if (!binaryFile.exists() || binaryFile.length() == 0L) {
                context.assets.open(assetName).use { inputStream ->
                    FileOutputStream(binaryFile).use { outputStream ->
                        inputStream.copyTo(outputStream)
                    }
                }
            }

            // Grant execute permissions on the copied executable
            if (!binaryFile.canExecute()) {
                val chmod = Runtime.getRuntime().exec(arrayOf("chmod", "755", binaryFile.absolutePath))
                chmod.waitFor()
            }

            return@withContext binaryFile.canExecute()
        } catch (e: Exception) {
            _engineOutputs.emit(EngineResponse.Error("Failed to extract Stockfish binary: ${e.localizedMessage}"))
            false
        }
    }

    /**
     * Launches the Stockfish subprocess and starts listening to stdout.
     */
    suspend fun start() = withContext(Dispatchers.IO) {
        if (isRunning.get()) return@withContext

        try {
            val binaryFile = File(context.filesDir, "stockfish")
            if (!binaryFile.exists()) {
                initialize()
            }

            val processBuilder = ProcessBuilder(binaryFile.absolutePath)
            processBuilder.redirectErrorStream(true)
            
            val proc = processBuilder.start()
            process = proc
            reader = BufferedReader(InputStreamReader(proc.inputStream))
            writer = OutputStreamWriter(proc.outputStream)
            isRunning.set(true)

            // Spawn background coroutine to parse engine outputs
            scope.launch { listenToEngineStdout() }

            // Initialize UCI protocol
            sendCommand("uci")
            sendCommand("isready")
        } catch (e: Exception) {
            _engineOutputs.emit(EngineResponse.Error("Failed to start Stockfish process: ${e.localizedMessage}"))
        }
    }

    /**
     * Stops the Stockfish engine and releases processes.
     */
    fun stop() {
        if (!isRunning.getAndSet(false)) return
        try {
            sendCommand("quit")
            process?.destroy()
        } catch (e: Exception) {
            // Safe ignore
        } finally {
            process = null
            reader = null
            writer = null
        }
    }

    /**
     * Sends a raw command line to the Stockfish stdin.
     */
    fun sendCommand(command: String) {
        scope.launch(Dispatchers.IO) {
            try {
                writer?.let {
                    it.write(command + "\n")
                    it.flush()
                }
            } catch (e: Exception) {
                _engineOutputs.emit(EngineResponse.Error("Failed to send command: $command. Error: ${e.localizedMessage}"))
            }
        }
    }

    /**
     * Configures Stockfish's parameters like hash memory size and CPUs.
     */
    fun configureEngine(threads: Int = 2, hashMemoryMb: Int = 64, skillLevel: Int = 20) {
        sendCommand("setoption name Threads value $threads")
        sendCommand("setoption name Hash value $hashMemoryMb")
        sendCommand("setoption name Skill Level value $skillLevel")
    }

    /**
     * Begins move calculation for a specific Board FEN state.
     * @param fen Standard chess algebraic board description
     * @param depth Search depth limit (e.g. 15 levels)
     * @param searchTimeMs Timeout limit in milliseconds
     */
    fun analyzePosition(fen: String, depth: Int = 12, searchTimeMs: Long? = null) {
        sendCommand("position fen $fen")
        if (searchTimeMs != null) {
            sendCommand("go depth $depth movetime $searchTimeMs")
        } else {
            sendCommand("go depth $depth")
        }
    }

    /**
     * Reads and parses lines from the Stockfish input stream.
     */
    private suspend fun listenToEngineStdout() {
        try {
            var line: String?
            while (isRunning.get()) {
                line = reader?.readLine() ?: break
                parseLine(line)
            }
        } catch (e: Exception) {
            _engineOutputs.emit(EngineResponse.Error("Engine standard stream closed: ${e.localizedMessage}"))
        }
    }

    /**
     * Translates UCI standard output messages into app events.
     */
    private suspend fun parseLine(line: String) {
        when {
            line.startsWith("readyok") -> {
                _engineOutputs.emit(EngineResponse.Ready(true))
            }
            line.startsWith("bestmove") -> {
                // Formatting is: bestmove e2e4 ponder e7e5
                val parts = line.split(" ")
                if (parts.size >= 2) {
                    _engineOutputs.emit(EngineResponse.BestMove(parts[1]))
                }
            }
            line.startsWith("info") && line.contains("score") -> {
                // Info line details look like: info depth 10 seldepth 12 score cp 35 nodes 452243 nps 12301
                try {
                    val parts = line.split(" ")
                    val depthIndex = parts.indexOf("depth")
                    val depth = if (depthIndex != -1 && depthIndex + 1 < parts.size) parts[depthIndex + 1].toIntOrNull() ?: 0 else 0
                    
                    var centipawns: Int? = null
                    var mateInMoves: Int? = null
                    val scoreIndex = parts.indexOf("score")
                    
                    if (scoreIndex != -1 && scoreIndex + 2 < parts.size) {
                        val type = parts[scoreIndex + 1] // cp or mate
                        val value = parts[scoreIndex + 2].toIntOrNull()
                        if (type == "cp") {
                            centipawns = value
                        } else if (type == "mate") {
                            mateInMoves = value
                        }
                    }

                    // Extract principal variation line moves
                    val pvIndex = parts.indexOf("pv")
                    val pvMoves = if (pvIndex != -1 && pvIndex + 1 < parts.size) {
                        parts.subList(pvIndex + 1, parts.size)
                    } else null

                    _engineOutputs.emit(EngineResponse.Info(
                        depth = depth,
                        centipawns = centipawns,
                        mateInMoves = mateInMoves,
                        bestLine = pvMoves,
                        raw = line
                    ))
                } catch (e: Exception) {
                    // Fail-safe parsing
                    _engineOutputs.emit(EngineResponse.Info(0, null, null, null, line))
                }
            }
        }
    }
}