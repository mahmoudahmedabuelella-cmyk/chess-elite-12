package com.chess.elite.ui.navigation

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.Extension
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.compose.ui.unit.dp

sealed class Screen(val route: String, val title: String, val icon: ImageVector) {
    object Home : Screen("home", "Home", Icons.Default.Home)
    object Play : Screen("play", "Play", Icons.Default.PlayArrow)
    object Puzzles : Screen("puzzles", "Puzzles", Icons.Default.Extension)
    object Analysis : Screen("analysis", "Analysis", Icons.Default.Analytics)
    object Settings : Screen("settings", "More", Icons.Default.Settings)
}

/**
 * Root Navigation Container for Chess Elite featuring Bottom Navigation setup.
 */
@Composable
fun ChessEliteAppNavigation() {
    val navController = rememberNavController()
    val screens = listOf(
        Screen.Home,
        Screen.Play,
        Screen.Puzzles,
        Screen.Analysis,
        Screen.Settings
    )

    Scaffold(
        bottomBar = {
            NavigationBar {
                val navBackStackEntry by navController.currentBackStackEntryAsState()
                val currentRoute = navBackStackEntry?.destination?.route

                screens.forEach { screen ->
                    NavigationBarItem(
                        icon = { Icon(imageVector = screen.icon, contentDescription = screen.title) },
                        label = { Text(text = screen.title) },
                        selected = currentRoute == screen.route,
                        onClick = {
                            if (currentRoute != screen.route) {
                                navController.navigate(screen.route) {
                                    popUpTo(navController.graph.findStartDestination().id) {
                                        saveState = true
                                    }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            }
                        }
                    )
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = Screen.Home.route,
            modifier = Modifier.padding(innerPadding)
        ) {
            composable(Screen.Home.route) {
                HomeScreen(
                    onNavigateToPlay = { navController.navigate(Screen.Play.route) },
                    onNavigateToPuzzles = { navController.navigate(Screen.Puzzles.route) }
                )
            }
            composable(Screen.Play.route) {
                PlayScreen()
            }
            composable(Screen.Puzzles.route) {
                PuzzlesScreen()
            }
            composable(Screen.Analysis.route) {
                AnalysisScreen()
            }
            composable(Screen.Settings.route) {
                SettingsScreen()
            }
        }
    }
}

// Below are standard Composable Page skeletons to link coordinates
@Composable
fun HomeScreen(onNavigateToPlay: () -> Unit, onNavigateToPuzzles: () -> Unit) {
    Text("Dashboard Home Screen", modifier = Modifier.padding(16.dp))
}

@Composable
fun PlayScreen() {
    Text("Vs Engine & Bluetooth Multiplayer Arena", modifier = Modifier.padding(16.dp))
}

@Composable
fun PuzzlesScreen() {
    Text("Lichess Puzzles Database Engine", modifier = Modifier.padding(16.dp))
}

@Composable
fun AnalysisScreen() {
    Text("Chess Review & Centipawn Analysis Engine", modifier = Modifier.padding(16.dp))
}

@Composable
fun SettingsScreen() {
    Text("Settings, Boards & Customization Rails", modifier = Modifier.padding(16.dp))
}