========================================================================
   🎓 CHESS ELITE - PROFESSIONAL ANDROID STUDIO GRADLE PROJECT SETUP 🚀
========================================================================

Congratulations! You have exported the full, native Chess Elite Android application.
This project is configured and pre-structured to build instantly with Android Studio and Gradle.

------------------------------------------------------------------------
📂 EXPORTED DIRECTORY & MODULES STRUCTURE:
------------------------------------------------------------------------
- android/settings.gradle       : Multi-project and dependency repositories definitions.
- android/gradle.properties     : Gradle Daemon, JVM allocation limits, and AndroidX / Jetifier compatibility flags.
- android/build.gradle          : Top-level build file for top-level tasks and Android Gradle Plugin config.
- android/app/build.gradle      : App Module build config. Imports Jetpack Compose, Room Database, and bhlangonijr-chesslib.
- android/app/src/main/AndroidManifest.xml : Registers App name, launchers, MainActivity runtime, and system level permissions (Vibrator / Bluetooth).
- android/app/src/main/assets/   : Contains native embedded chess solver assets (Stockfish 18 ARMv8-a CPU binary).
- android/app/src/main/java/     : Full 100% Core Kotlin source code tree.
    └── com/chess/elite/
         ├── MainActivity.kt         : Primary Activity bootstraps Jetpack Compose content views.
         ├── data/GameDatabase.kt   : Room database entity controllers, DAOs, and SQLite storage caches.
         ├── engine/StockfishEngine.kt : UCI Pipeline controller thread communicating with Stockfish.
         ├── ui/board/ChessBoard.kt : Declarative 100% Jetpack Compose Chessboard with animations & gesturals.
         └── ui/navigation/Navigation.kt : Declarative bottom bar UI router, scaffold and page routing.
- android/app/src/main/res/      : Core layouts, strings, styling assets, and launcher icons.

------------------------------------------------------------------------
🛠️ HOW TO BUILD THE APK IN ANDROID STUDIO:
------------------------------------------------------------------------
1. Extract the container contents of this .ZIP archive to your local workbench folder.
2. Launch Google Android Studio (preferably version "Giraffe / Hedgehog / Iguana" or newer).
3. Select "Open Project" or "Import Project" in the Android Studio launch window.
4. Navigate and select the root directory named `android` and click OK.
5. Wait for Android Studio to complete the initial Gradle Sync. Standard internet connection is required to fetch com.github.bhlangonijr:chesslib and active Jetpack Compose packages.
6. Install NDK/SDK packages if Android Studio prompts you to match "MinSdk 26" and "CompileSdk 34" options.
7. Run and Test: Connect an Android physical emulator or real smartphone via developer USB options, and select "Run 'app'" or click the Green Play button in the top status bar.
8. Build APK: Go to Build > Build Bundle(s) / APK(s) > Build APK(s). Once built, you can copy the APK installer from "android/app/build/outputs/apk/debug/app-debug.apk" directly to build devices!

========================================================================
Have fun coding and extending your Chess Elite Native Android Application!
Copyright (c) 2026. Standard Chess Elite Authors. Licensed under Apache 2.0.
========================================================================
